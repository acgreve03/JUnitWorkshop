import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeAll;

public class HauntedTest {

    static HauntedHouse house;

    @BeforeAll
    public static void setup(){
        house = new HauntedHouse();
    }

    @Test
    public void ghostPresenceTest(){
        Assertions.assertEquals(true, house.isGhostPresent());
    }

    @Test
    public void scareGhostTest(){
        house.scareAwayGhost();
        Assertions.assertEquals(false, house.isGhostPresent());
    }

    @Test
    public void scarySoundTest(){
        house.spookySound();
        Assertions.assertEquals("Boo!", house.spookySound());
    }

    @Test
    public void CandyZeroTest() {
        house.candyZero();
        Assertions.assertEquals(0, house.getCandyCount());
    }

    @Test
    public void CandyRefillLarge(){
        house.refillCandyBowl(100);
        Assertions.assertEquals(110, house.getCandyCount());
    }

    @Test
    public void CandyRefillInfinite(){
        house.refillCandyBowl(Integer.MAX_VALUE);
        Assertions.assertEquals(Integer.MAX_VALUE, house.getCandyCount());
    }

    @Test
    public void candyRefillNoCandyHouse(){
        house.refillCandyBowl(0);
        Assertions.assertEquals(10, house.getCandyCount());
    }

    @Test
    public void candyRefillNegative1(){
        house.refillCandyBowl(-1);
        Assertions.assertEquals(10, house.getCandyCount());
    }

    @Test
    public void candyRefill(){
        house.refillCandyBowl(-50);
        Assertions.assertEquals(10, house.getCandyCount());
    }

    @Test
    public void candyRefillNegative2(){
        house.refillCandyBowl(-2);
        Assertions.assertEquals(10, house.getCandyCount());

    }

    @Test
    public void candyRefillNegative3(){
        house.refillCandyBowl(-3);
        Assertions.assertEquals(10, house.getCandyCount());

    }

    @Test
    public void trickOrTreatTest(){
        house.trickOrTreat(10);
        Assertions.assertEquals(0, house.getCandyCount());
    }

    @Test
    public void tooManyPeople(){
        house.trickOrTreat(12);
        Assertions.assertEquals(0, house.getCandyCount());
    }

    @Test
    public void runningLowTest(){
        house.trickOrTreat(9);
        Assertions.assertEquals(1, house.getCandyCount());
        house.trickOrTreat(1);
        Assertions.assertEquals(0, house.getCandyCount());
        house.runningLow();
        Assertions.assertEquals(10, house.getCandyCount());
    }

    @Test
    public void bringGhostBackTest(){
        house.scareAwayGhost();
        Assertions.assertEquals(false, house.isGhostPresent());
        house.bringGhostBack();
        Assertions.assertEquals(true, house.isGhostPresent());
    }





}
