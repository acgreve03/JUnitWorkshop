public class Main {
    public static void main(String[] args) {
        HauntedHouse h1 = new HauntedHouse();
        boolean b = h1.isGhostPresent();
        System.out.println(b);
    }
}